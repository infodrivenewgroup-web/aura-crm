
## Deploying a separate copy

1. Create a new Vercel project from this source and deploy it.
2. Add the variables from `.env.example` for the required environments.
3. Provision a PostgreSQL database (for example, Neon) and set `DATABASE_URL`.
4. Redeploy after adding or changing environment variables.

This export intentionally omits all secret values. `DYXLESS_TOKEN` was removed from source fallback values and must be configured through the environment.
